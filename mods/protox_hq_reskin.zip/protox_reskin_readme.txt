================================
[  Protox High Quality Reskin  ]
================================

================
[     Info     ]
================
 Author: Protox
 Email: radicalmonday@gmail.com
 Blog: http://ubuntucorner.blogspot.com
 deviantART: http://primoturbo.deviantart.com
 Version: 1.0 (released March 29, 2011)
 Overview: 
 This mod modifies all the default player skins for Assault Cube 1.1 with high quality reskins.
 The resolution of these skins is 2 times (from 320x200, to 640x400) the originals.

================
[   Included   ]
================
 playermodels\CLA\01.jpg
 playermodels\CLA\01_redvest.jpg
 playermodels\CLA\02.jpg
 playermodels\CLA\02_redvest.jpg
 playermodels\CLA\03.jpg
 playermodels\CLA\03_redvest.jpg
 playermodels\CLA\04.jpg
 playermodels\CLA\04_redvest.jpg
 playermodels\CLA\red.jpg
 playermodels\RVSF\01.jpg
 playermodels\RVSF\01_bluevest.jpg
 playermodels\RVSF\02.jpg
 playermodels\RVSF\02_bluevest.jpg
 playermodels\RVSF\03.jpg
 playermodels\RVSF\03_bluevest.jpg
 playermodels\RVSF\04.jpg
 playermodels\RVSF\04_bluevest.jpg
 playermodels\RVSF\05.jpg
 playermodels\RVSF\05_bluevest.jpg
 playermodels\RVSF\06.jpg
 playermodels\RVSF\06_bluevest.jpg
 playermodels\RVSF\blue.jpg
 playermodels\skin.jpg

================
[    How-To    ]
================
Windows: 
 Unzip the file and place the contents into your Assault Cube folder
 Start protox_reskin.bat

 This mod works with my protox mod, just put the contents together under one of the mods.
 e.g. copy everything inside /mods/protox_mod into /mods/protox_reskin, use protox_reskin.bat to start the game 

Other:
 The following argument is used to launch the mod: --mod=mods\protox_reskin

================
[Special Thanks] 
================
 Developers of Assault Cube
 Developers of Cube/Sauerbraten game and engine
 Assault Cube community and especially the official forums
 HitmanDaz[MT] for creating the original S.A.S (Special Air Service) model and skins

================
[    LICENSE   ]
================
 Public Domain
================
Note:
 I'm releasing these skins under no license and therefore they are now part of public domain.
 You can modify the skins and re-release them without any restrictions. 
 Please keep in mind that it is only my skins that are under public domain, the original model is by HitmanDaz[MT] (Darren Pattenden). 
 Follow his license if you want to include the model with any modifications.
 This mod only includes the skins that I have made, the lack of licensing is to allow unhindered re-distribution. 
 I figure people will want to modify the skins for themselves and for their clans, and re-release without the burden of violating licensing.
 Enjoy :)
